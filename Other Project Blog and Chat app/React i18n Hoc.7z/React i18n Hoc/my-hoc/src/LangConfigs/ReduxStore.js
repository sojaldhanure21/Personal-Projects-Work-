import {createStore} from 'redux'
const langdetector = (state = { lang: "en" }, action) => {
  if (action.type === "en") {
    return { lang: (state.lang = "en") };
  }
  if (action.type === "fr") {
    return { lang: (state.lang = "fr") };
  }

  return state;
};

export const store = createStore(langdetector); 