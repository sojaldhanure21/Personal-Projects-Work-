export const enmsg={ 
    "Hi" :"Hi",
    "Hello":"Hello i am sojal ",
    "I am sojal":"I am sojal "
}

export const frmsg={ 
    "Hi" :"Salut",
    "Hello":"Bonjour, je suis sojal  ",
    "I am sojal":"I am sojal "

 }