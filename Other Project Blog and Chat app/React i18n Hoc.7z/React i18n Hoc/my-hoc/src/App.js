import './App.css';
import Home from './HOC/HomeView';
import { Provider } from 'react-redux/es/exports';
import { store } from './LangConfigs/ReduxStore';
function App() {
  return (
    <div className="App">
      <Provider store={store}>
      <Home />
      </Provider>    </div>
  );
}

export default App;
