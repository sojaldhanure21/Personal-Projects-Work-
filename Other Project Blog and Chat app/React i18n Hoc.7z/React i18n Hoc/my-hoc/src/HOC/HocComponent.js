import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import i18n from "../LangConfigs/LangConfig";

export function HocComponent(...msg){
    const lang = useSelector((state)=>state.lang)
    const { t } = useTranslation();
    console.log("messages",...msg)
useEffect(()=> {i18n.changeLanguage(lang)},[lang]) 
return t(...msg);
    
}