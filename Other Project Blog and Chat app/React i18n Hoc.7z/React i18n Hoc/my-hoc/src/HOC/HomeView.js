import { useSelector, useDispatch } from "react-redux";
import { HocComponent } from "./HocComponent";

function Home() {
  const dispatch = useDispatch();
  const lang = useSelector((state) => state.lang);
  console.log("lang", lang);
  
  const langdetector = ({ target }) => {
    let value = target.value;
    console.log("target", value);
    dispatch({ type: value });
  };
  return (
    <div>
      <select onChange={langdetector} value= {lang}>
        <option value="en">English</option>
        <option value="fr">French</option>
      </select>
      <br />
      <label>{HocComponent("Hi")}</label>
      <br />
      <label>{HocComponent("Hello")}</label>
    </div>
  );
}

export default Home;
