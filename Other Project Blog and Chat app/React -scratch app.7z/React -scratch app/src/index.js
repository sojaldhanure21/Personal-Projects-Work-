import React from "react";
import ReactDOM  from "react-dom";
import { Router,Route,Routes } from "react-router-dom";
import { lazy,Suspense  } from "react";

const Home = lazy (()=> import("./Home"))
const Login = lazy(()=>import("./Login"))
const App=()=>
 { return(
 <Router>
  <Suspense fallback= {<div>Loading Component ....</div>}>
  <Routes>
      <Route path='/' element ={<Home/>} />
      <Route path='/home' element ={<Login/>} />
  </Routes>
  </Suspense>
</Router>)}
ReactDOM.render(<App/>,document.getElementById("root"))