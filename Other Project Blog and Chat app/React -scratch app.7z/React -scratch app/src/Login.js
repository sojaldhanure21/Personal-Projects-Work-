const Login = ()=>{
    return <div>login page</div>
}

export default Login