const Home = ()=>{
    return <div>login page</div>
}

export default Home