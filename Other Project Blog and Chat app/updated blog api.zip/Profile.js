import { useNavigate } from "react-router-dom";

// profile blog get props from log to profile
function Profile(props) {
  const navigate = useNavigate();

  //  navigate to detailBlogs
  function detailBlogs(e) {
    console.log("details", e);


    navigate(`/detailblog/${e}`);
  }

  // navigate to edit blog
  function editblog() {
    navigate("/editblog");
  }

  return (
    <>
      {/* if props if reasponse write data using map method for reusability of code */}
      {props?.response?.map((blog, index) => {
        return (
          <div className="blog-card">
            <div className="blog-header">
              <div className="bolg-title"></div>
              <small className="blog-id">{blog?.id}</small>
              <br />
              <small className="bold-profile-id">{blog?.title}</small>
              <button type="button" onClick={editblog}>
                Edit
              </button>
            </div>
            <div className="blog-body">
              <p className="blog-describe-data">{blog?.body}</p>
              <button onClick={(e) => detailBlogs(blog.id)}>
                .....Show More
              </button>

              <div className="blog-auther"></div>
            </div>
            <div className="blog-fotter">
              <div className="blog-like">
                <form>
                  <input type="button" name="like" />
                  <span></span>
                </form>
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}
export default Profile;
