function BlogReplies(){
    return(<div>reply</div>);
}

export default BlogReplies;