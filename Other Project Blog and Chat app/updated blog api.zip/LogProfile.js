import Profile from "./Profile";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useState, useEffect } from "react";

//Main Function Log to Profile
function LogToProfile() {
  const navigate = useNavigate();
  const [res, setBlogs] = useState([]);

  // use effect used
  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((request) => {

        // setblog State 
        setBlogs(request.data);
        if (request) {
          console.log(request.data);
        } else {
          alert("No Data Found");
        }
      })

      .catch((err) => {
        alert(err);
      });
  }, []);
  console.log("arrys", res);

// navigate to create blog page
  function createBlog() {
    navigate("/createblog");
  }

  return (
    <div>
      <div>
        <div>Your Blogs</div>
      </div>
      <div>
        <button type="button" onClick={createBlog}>
          Create Blog
        </button>
      </div>
      <div>
        <Profile response={res}></Profile>
      </div>
     </div>
  );
}

export default LogToProfile;
