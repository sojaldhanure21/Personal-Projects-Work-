// import BlogComments from "./BlogComment";
import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function DetailBlogs() {
  const a = useParams();

  console.log("blog id from profile", a);

  let [setBlog, setBlogs] = useState([]);
  let [like, setLikes] = useState(setBlog.likes);
  let [comments, setComments] = useState([]);

  // To handle like event
  let likes = (e) => {
    like = setLikes(e.target.value);
    console.log(typeof like);
  };

  // to get parameter from routes
  if (setBlog.postId === a.id) {
    console.log(setBlog);
  }

  // to get value recived from get blog
  console.log(setBlog);

  // to get the specific blog data
  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/comments")
      .then((res) => {
        // to set the blog
        setBlogs(res.data[0]);

        if (res) {
          res.data.map((elem, index) => {
            return (elem["likes"] = 1);

            // elem["username"]= elem.email+elem.id;
          });
        } else {
          alert("No Data Found");
        }
      })

      .catch((err) => {
        alert("No data find");
      });
  }, []);

  // to get the comments
  function Comments() {
     const cmnt = comments;
     console.log("commnets",comments)

      axios
        .get("https://jsonplaceholder.typicode.com/comments")
        .then((response) => {
          // to set the comments
          setComments(response.data[0])
          if (response.data) {

            // response.data.map((elem, index) => {
            console.log("comments received", response.data)
            // return elem;  
          // }
          //   )
           }
             // map method ends
          })

        .catch((error) => {
          console.log("No Comments Found");
        },[]);
       
  }

  // to post the comments
function postComment(){

}

  return (
    <div>
      <header>{setBlog.postId}</header>
      <label>{setBlog.name}</label>
      <p>{setBlog.body}</p>
      <div>
        <button onClick={(e) => setLikes(setBlog.like + 1)}>Like</button>
        <button onClick={Comments}>comments</button><br/>
        <input type="text" placeholder="Enter the comment" onClick={postComment}></input>
        <button>Post</button>
        
      </div>
      {/* <label>{setBlog.likes}</label><br/> */}
      <div>
        <label>Comments</label>
        <br/>
        <label>1-{comments.email}</label><br/>
        <label>{comments.body}</label>
        <button>reply</button>

      </div>
    </div>
  );
}

export default DetailBlogs;
