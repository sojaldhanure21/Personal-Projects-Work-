import "../styled/Middle.css";
import Blog from "./Blog";
import { useNavigate } from "react-router-dom";


var demo = [
  {
    blog_id: 1001,
    profile_id: "saurabh",
    profile_name: "saurabh dudhalwar",
    title: "Moving forward",
    describes:
      "We have found  Paragraphs and associated modules to be a very successful recipe. Our clients love the plugability and extensibility of the system. if they need something new then we can build it. Oftentimes they are happy with the standard Paragraph bundles we can provide with Paragraphs pack. We are therefore continuing to build the ecosystem to support our own site building efforts. Bundles which have general application will be released back into Paragraphs Pack.",
    like_count: 20,
  },
  {
    blog_id: 1002,
    profile_id: "sopan",
    profile_name: "sopan masure",
    title: "Why do we use it",
    describes:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)",
    like_count: 30,
  },
  {
    blog_id: 1003,
    profile_id: "akshay",
    profile_name: "akshay khole",
    title: "Lorem Ipsum",
    describes:
      "simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    like_count: 50,
  },
  {
    blog_id: 1004,
    profile_id: "akshay",
    profile_name: "akshay khole",
    title: "Lorem Ipsum",
    describes:
      "simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    like_count: 50,
  },
  {
    blog_id: 1005,
    profile_id: "akshay",
    profile_name: "akshay khole",
    title: "Lorem Ipsum",
    describes:
      "simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    like_count: 50,
    dislike_count: 20,
  },
  {
    blog_id: 1006,
    profile_id: "akshay",
    profile_name: "akshay khole",
    title: "Lorem Ipsum",
    describes:
      "simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    like_count: 50,
  },
  {
    blog_id: 1007,
    profile_id: "akshay",
    profile_name: "akshay khole",
    title: "Lorem Ipsum",
    describes:
      "simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    like_count: 50,
  },
];

function Middle() {

  const navigate = useNavigate()

  function profileRedireect(){
    navigate("/logtoprofile")
  }
  return (
    <div className="middle-baground">
      <div>
        <button onClick={profileRedireect}>Profile</button>
      </div>
      <div>
        <form>
          <div>
            {demo.map((ele, i) => {
              return (
                <Blog className="middle-content" key={ele.id} data={ele} />
              );
            })}
          </div>
        </form>
      </div>
    </div>
  );
}
export default Middle;
