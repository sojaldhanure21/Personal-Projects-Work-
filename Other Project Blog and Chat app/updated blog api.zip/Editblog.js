import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function Editblog() {
  const a = useParams();

  console.log("blog id from profile", a);

  let [setBlog, setBlogs] = useState([]);
  let [title, setTitle] = useState();
  let [blog, changeBlog] = useState();

  // to get parameter from routes
  if (setBlog.postId === a.id) {
    console.log(setBlog);
  }

  // to get value recived from get blog
  console.log(setBlog);

  // to get the specific blog data
  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/comments")
      .then((res) => {
        // to set the blog
        setBlogs(res.data[0]);

        if (res) {
          res.data.map((elem, index) => {
            // elem["name"] = title;
          });
        } else {
          alert("No Data Found");
        }
      })

      .catch((err) => {
        alert("No data find");
      });
  }, []);

  function titleChanged(e) {
    setTitle(e.target.value);
  }

  function blogEdited(e) {
    changeBlog(e.target.value);
  }

  return (
    <div>
      <div>
        <label>BlogID:</label>
        <header>{setBlog.postId}</header>
        <br />
        <label>{setBlog.email}</label>
        <br />

        <label>Title:</label>
        <input value={setBlog.name} onChange={titleChanged}></input>
        <br />
        <label>Blog:</label>
        <textarea onChange={blogEdited} value={setBlog.body}></textarea>
        <button>Post</button>
      </div>
    </div>
  );
}
export default Editblog;
