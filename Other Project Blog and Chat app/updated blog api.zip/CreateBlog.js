import axios from "axios";
import "../styled/Cblog.css";
import { useNavigate } from "react-router-dom"
function CreateBlog() {

    const navigate = useNavigate()

  function submitBlog(e) {
    e.preventDefault();
    let request = {
      profile_id: "",
      blog_Title: document.getElementById("createBlog_title").value,
      blog_describe: document.getElementById("createBlog_describe").value,
    };
    axios.post("http://localhost:3000/focusblog/", request).then((res) => {
      if(res.data === "Success"){
        navigate('/middle')
      }
    });
  }

  return (
    <div className="mbody">
      <form onSubmit={(e) => submitBlog(e)}>
        <div>
          <label>Enter Blog Title:</label>
          <input
            type="text"
            placeholder="Title"
            id="createBlog_title"
            required
          />
        </div>
        <div>
          <label>Describtion</label>
          <input
            type="text"
            placeholder="Write your blog here..... "
            id="createBlog_describe"
            required
          />
        </div>
        <div>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}
export default CreateBlog;
