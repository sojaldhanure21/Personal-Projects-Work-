import axios from "axios";
import "../styled/Login.css";
import { useNavigate } from "react-router-dom"
function Login() {
  const navigate = useNavigate();
  function loginToblog(e) {
    e.preventDefault();
    let request = {
      email: document.getElementById("email").value,
      password: document.getElementById("password").value,
    };

    axios
      .post("http://localhost:3000/LoginUser", request)
      .then((res) => {
        if(res.data !=="success") {
          alert('Login Failed');
        } else {
          navigate("/middle");
        }

      })
      .catch((err) => {
        console.log(err);
        // window.alert("hello")
      });
  }

  return (
    <div className="loginBack">
      <div className="siteName">Blogger.com</div>
      <div className="mainFormDiv">
        <form onSubmit={(e) => loginToblog(e)}>
          <div className="userNameDiv">
            <label className="userName">Username :</label>
            <br />
            <input
              type="email"
              id="email"
              name="email"
              className="inputField"
              required
            />
          </div>
          <div className="passWordDiv">
            <label className="passWord">Password :</label>
            <br />
            <input
              type="password"
              id="password"
              name="password"
              className="inputField"
              required
            />
          </div>
          <div className="loginButton">
            <button type="submit" className="login">
              Login
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;
