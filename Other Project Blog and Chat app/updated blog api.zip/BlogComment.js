import BlogReplies from "./CommentReply";
function BlogComments(){

    return(<div>
        Welcome to BlogComments
        <button>Comments</button>
        <div>
            <ul>Comments
                <li>good</li>
            </ul>
            <div><BlogReplies/></div>
        </div>
    </div>)
}
export default BlogComments;