import axios from "axios";
import { useEffect } from "react";
import "../styled/Focusblog.css";

function Focusblog() {
  useEffect(() => {
    let request = window.location.pathname;
    console.log(request.toString().slice(11));

    axios.post("http://localhost:3000/focusblog/", request).then((res)=>{
      const singleBlog = res.data
      console.log(singleBlog)
    })
  });

  return (
    <div className="main-page">
      <div className="single-card">
        <div className="single-header">
          <div className="single-title">Title</div>
        </div>
        <div className="single-body">
          <p className="single-para">para</p>
          <div className="single-Auther">auther</div>
        </div>
        <div className="single-footer">
          <div className="single-like">
            <form>
              <input type="button" name="like" />
              <span>Like</span>
            </form>
          </div>
          <div className="single-dislike">
            <form>
              <input type="button" name="dislike" />
              <span>Dislike</span>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Focusblog;
