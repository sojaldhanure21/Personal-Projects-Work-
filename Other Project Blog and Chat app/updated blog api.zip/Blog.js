import "../styled/blog.css";
import { useNavigate } from "react-router-dom";
// import { useState } from "react"

function Blog({
  data: { blog_id, profile_id, profile_name, title, describes, like_count },
}) {
  // const [like_count,setlike_count] = useState(0)
  const navigate = useNavigate();

  function focusOnBlog() {
    navigate(`/focusblog/${blog_id}`);
  }

  function likeRequest() {
    document.getElementById(`${blog_id}`).innerHTML = "&#128150;";
  }

  return (
    <div className="blog-card">
      <div className="blog-header">
        <div className="bolg-title">{title}</div>
        <small className="blog-id">{blog_id}</small>
        <small className="bold-profile-id">{profile_id}</small>
      </div>
      <div className="blog-body">
        <div className="blog-describe">
          <p className="blog-describe-data">{describes}</p>
          <button type="button" className="show-more" onClick={focusOnBlog}>
            .....show more
          </button>
        </div>
        <div className="blog-auther">{profile_name}</div>
      </div>
      <div className="blog-fotter">
        <div className="blog-like">
          <button
            type="button"
            id={blog_id}
            className="like-button"
            onClick={()=>likeRequest()}
          >
            &#128155;
          </button>
          <span>{like_count}</span>
        </div>
      </div>
    </div>
  );
}
export default Blog;
